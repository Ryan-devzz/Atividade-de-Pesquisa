package Atividade;

import java.util.Scanner;

public class TratamentoDeExcecoes {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        try {
            // Leitura de valores digitados pelo usuário
            System.out.print("Digite um número inteiro: ");
            int numero1 = Integer.parseInt(scanner.nextLine()); 
            // Lança NumberFormatException em caso de texto inválido

            System.out.print("Digite outro número inteiro: ");
            int numero2 = Integer.parseInt(scanner.nextLine());
            // Também pode lançar NumberFormatException

            // Cálculo da divisão (pode lançar ArithmeticException)
            int resultado = dividir(numero1, numero2);
            System.out.println("Resultado da divisão: " + resultado);

        } 
        catch (NumberFormatException e) { 
            // Conversão inválida de texto para número
            System.out.println("Erro: você deve digitar apenas números inteiros.");
        }
        catch (ArithmeticException e) {  
            // Divisão por zero
            System.out.println("Erro matemático: " + e.getMessage());
        }
        catch (Exception e) {  
            // Outras exceções inesperadas
            System.out.println("Ocorreu um erro inesperado: " + e.getMessage());
        }
        finally {
            // Sempre executado independentemente de erro
            System.out.println("Encerrando o programa...");
            scanner.close();
        }
    }

    // Método auxiliar de divisão que pode lançar ArithmeticException
    public static int dividir(int a, int b) {
        return a / b; // exceção automática caso b == 0
    }
}
